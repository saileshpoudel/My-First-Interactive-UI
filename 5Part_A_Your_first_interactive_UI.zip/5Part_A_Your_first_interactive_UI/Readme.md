# 1.2 Part A: Your first interactive UI

* Task 1: Create and explore a new project -->*(Project: HelloToast)*
* Task 2: Add View elements in the layout editor -->*(Project: HelloToast)*
* Task 3: Change UI element attributes -->*(Project: HelloToast)*
* Task 4: Add a TextEdit and set its attributes -->*(Project: HelloToast)*
* Task 5: Edit the layout in XML -->*(Project: HelloToast)*
* Task 6: Add onClick handlers for the buttons -->*(Project: HelloToast)*
* Coding challenge -->*(Project: HelloToast)*
